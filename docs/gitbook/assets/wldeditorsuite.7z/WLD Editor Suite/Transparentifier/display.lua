
local field = {
	name = iup.text{readonly = "YES", visiblecolumns = 16},
	--offset = iup.text{readonly = "YES", visiblecolumns = 16},
	header_flag = iup.text{readonly = "YES", visiblecolumns = 16},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	other_flag = iup.text{readonly = "YES", visiblecolumns = 16},
	float1 = iup.text{readonly = "YES", visiblecolumns = 16},
	float2 = iup.text{readonly = "YES", visiblecolumns = 16},
	pair_u = iup.text{readonly = "YES", visiblecolumns = 16},
	pair_f = iup.text{readonly = "YES", visiblecolumns = 16},
	binary = iup.text{visiblecolumns = 24, mask = "[01]+"},
}

local grid = iup.gridbox{
	iup.label{title = "Name"}, field.name,
	--iup.label{title = "Offset"}, field.offset,
	iup.label{title = "Header Flag"}, field.header_flag,
	iup.label{title = "Visibility Flag"}, field.flag,
	iup.label{title = "Other Flag"}, field.other_flag,
	iup.label{title = "Float1"}, field.float1,
	iup.label{title = "Float2"}, field.float2,
	iup.label{title = "Pair Int"}, field.pair_u,
	iup.label{title = "Pair Float"}, field.pair_f;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 50, gaplin = 8, alignmentlin = "ACENTER"
}

local WriteFlag = WriteFlag
local pcall = pcall
local format = string.format
local tostring = tostring
local floor = math.floor
local concat = table.concat

local function Binary(n)
	local str = {}
	local i = 32
	for a = 1, 32 do
		str[i] = tostring(n % 2)
		i = i - 1
		n = floor(n / 2)
	end
	return concat(str)
end

local function ApplyEdit()
	local frag = selection
	local bin = field.binary.value
	if bin:len() < 32 then
		bin = string.rep("0", 32 - bin:len()) .. bin
	end
	local s, errmsg = pcall(WriteEditedBinary, wld_path, frag, bin)
	if s then
		frag.flag = errmsg
		UpdateDisplay(frag)
	else
		error_popup(errmsg)
	end
end

local edit = iup.button{title = "Apply Edit", action = ApplyEdit,
	active = "NO", padding = "10x0"}

function field.binary:action()
	edit.active = "YES"
end

function UpdateDisplay(frag)
	field.name.value = frag.name
	--field.offset.value = format("0x%0.8X", frag.offset)
	field.header_flag.value = format("0x%0.8X", frag.header_flag)
	field.flag.value = format("0x%0.8X", frag.flag)
	field.other_flag.value = format("0x%0.8X", frag.other_flag)
	field.float1.value = tostring(frag.float1)
	field.float2.value = tostring(frag.float2)
	field.pair_u.value = format("0x%0.8X", frag.pair_u)
	field.pair_f.value = tostring(frag.pair_f)
	field.binary.value = Binary(frag.flag)
	edit.active = "NO"
end

local function MakeSemiTransparent()
	local frag = selection
	if not frag then return end
	local s, errmsg = pcall(WriteFlag, wld_path, frag)
	if s then
		frag.flag = 0x80000017
		UpdateDisplay(frag)
	else
		error_popup(errmsg)
	end
end

button = iup.button{title = "Make Semi-transparent", action = MakeSemiTransparent,
	active = "NO", padding = "10x0"}

return iup.vbox{grid, iup.label{title = "Visibility Flag binary:"},
	field.binary, edit, button; alignment = "ACENTER", ngap = 8, nmargin = "10x0"}
