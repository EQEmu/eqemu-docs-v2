
local list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 10}

local ipairs = ipairs

function UpdateList(tbl)
	list[#tbl + 1] = nil
	for pos, frag in ipairs(tbl) do
		list[pos] = frag.name
	end
	if #tbl > 0 then
		button.active = "YES"
	else
		button.active = "NO"
	end
end

function list:action(str, pos, state)
	if state == 1 then
		local frag = main_list[pos]
		if frag then
			selection = frag
			UpdateDisplay(frag)
		end
	end
end

return list
