
list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 12}

local list = list
local ipairs = ipairs

function UpdateList(tbl)
	list[#tbl + 1] = nil
	for pos, name in ipairs(tbl) do
		list[pos] = name
	end
end

function list:action(str, pos, state)
	if state == 1 and str then
		button.active = "YES"
		copy_name = str
	end
end

return list
