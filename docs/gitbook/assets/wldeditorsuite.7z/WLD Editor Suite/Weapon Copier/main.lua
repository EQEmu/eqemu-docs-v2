
function assert(result, msg)
	if result then return result end
	local err = iup.messagedlg{buttons = "OK", dialogtype = "ERROR", title = "Error", value = msg}
	iup.Popup(err)
	iup.Close()
end

function error_popup(msg)
	local err = iup.messagedlg{buttons = "OK", dialogtype = "ERROR", title = "Error", value = msg}
	iup.Popup(err)
end

local list = require "list"
local display = require "display"

local pcall = pcall
local LoadWLDInfo = LoadWLDInfo
local UpdateList = UpdateList
local UpdateDisplay = UpdateDisplay

local function HandleLoad()
	local dlg = iup.filedlg{title = "Select WLD", extfilter = "*.wld (WLD Files)|*.wld|"}
	iup.Popup(dlg)
	if dlg.status == "0" then
		local path = dlg.value
		if path then
			local s, tbl = pcall(LoadWeaponIDs, path)
			if s then
				wld_path = path
				UpdateList(tbl)
			else
				error_popup(tbl)
			end
		end
	end
end

local menu = iup.menu{
	iup.submenu{
		title = "&File";
		iup.menu{
			iup.item{title = "Open WLD", action = HandleLoad},
		},
	},
}

local window = assert(iup.dialog{iup.hbox{list, display; nmargin = "10x10"};
	title = "WLD Weapon Copier", menu = menu, size = "240x200"})

function window:k_any(key)
	if key == iup.K_ESC then
		iup.Close()
	end
end

window:show()
iup.MainLoop()
