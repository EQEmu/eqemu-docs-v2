
local input_id = iup.text{visiblecolumns = 10, mask = "/d+"}

local function Click()
	local id = tonumber(input_id.value)
	if id and copy_name then
		local s, err = pcall(CopyWeapon, wld_path, copy_name, "IT" .. id)
		if s then
			local s, tbl = pcall(LoadWeaponIDs, wld_path)
			if s then
				UpdateList(tbl)
			else
				error_popup(tbl)
			end
		else
			error_popup(err)
		end
		button.active = "NO"
	end
end

button = iup.button{title = "Copy Model", margin = "10x0", active = "NO", action = Click}

return iup.vbox{input_id, button; margin = "10x10", alignment = "ACENTER", gap = 10}
