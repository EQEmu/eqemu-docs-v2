
list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 18}

local list = list
local ipairs = ipairs

function UpdateList(tbl)
	list[#tbl + 1] = nil
	for pos, frag in ipairs(tbl) do
		list[pos] = frag.name
	end
end

function list:action(str, pos, state)
	if state == 1 then
		local frag = main_list[pos]
		if frag then
			UpdateDisplay(frag, frag.type)
		end
	end
end

return list
