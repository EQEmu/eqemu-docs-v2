
function CreateDisplay(box, func)
	local d = {display = box, Update = func}
	return d
end

local format = string.format
function hex(int)
	return format("0x%0.8X", int)
end

local display = {
	header = require("types/header"),
	frag03 = require("types/frag03"),
	frag04 = require("types/frag04"),
	frag05 = require("types/frag05"),
	frag10 = require("types/frag10"),
	frag11 = require("types/frag11"),
	frag12 = require("types/frag12"),
	frag13 = require("types/frag13"),
	frag14 = require("types/frag14"),
	frag2D = require("types/frag2D"),
	frag30 = require("types/frag30"),
	frag31 = require("types/frag31"),
	frag36 = require("types/frag36"),
}

local type_to_display = {
	[0x00] = display.header,
	[0x03] = display.frag03,
	[0x04] = display.frag04,
	[0x05] = display.frag05,
	[0x10] = display.frag10,
	[0x11] = display.frag11,
	[0x12] = display.frag12,
	[0x13] = display.frag13,
	[0x14] = display.frag14,
	[0x2D] = display.frag2D,
	[0x30] = display.frag30,
	[0x31] = display.frag31,
	[0x36] = display.frag36,
}

local none_type = iup.text{readonly = "YES", visiblecolumns = 16}
local none = CreateDisplay(iup.hbox{iup.label{title = "Type"}, none_type; nmargin = "10x10", gap = 10, alignment = "ACENTER"},
	function(f) none_type.value = format("0x%0.2X", f.type) end)

type_to_display.__index = function() return none end
setmetatable(type_to_display, type_to_display)

local zbox = iup.zbox{
	none.display,
	value = none.display
}

for _, d in pairs(display) do
	iup.Append(zbox, d.display)
end

function UpdateDisplay(frag, type)
	local d = type_to_display[type]
	d.Update(frag)
	zbox.value = d.display
end

return zbox
