
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x12 (Animation Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	num = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Num Frames"}, field.num;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2
}

local hex = hex
local tostring = tostring
local frag

local function Update(f)
	field.flag.value = hex(f.flag)
	field.num.value = tostring(f.num)
	frag = f
end

local floor = math.floor

local function Click()
	local max = frag.num + 1
	local gauge = iup.val{min = 1, max = max, step = 1 / frag.num - 1, value = 1, size = "150x20"}
	local af = frag.frames
	local count = iup.text{readonly = "YES", visiblecolumns = 2}
	local rotx = iup.text{readonly = "YES", visiblecolumns = 16}
	local roty = iup.text{readonly = "YES", visiblecolumns = 16}
	local rotz = iup.text{readonly = "YES", visiblecolumns = 16}
	local shfx = iup.text{readonly = "YES", visiblecolumns = 16}
	local shfy = iup.text{readonly = "YES", visiblecolumns = 16}
	local shfz = iup.text{readonly = "YES", visiblecolumns = 16}
	function gauge:valuechanged_cb()
		local v = floor(self.value)
		if v > max then v = max end
		self.value = v
		local frame = af[v]
		if frame then
			count.value = tostring(v)
			if frame.rotX then
				rotx.value = tostring(frame.rotX)
				roty.value = tostring(frame.rotY)
				rotz.value = tostring(frame.rotZ)
			else
				rotx.value = "0"
				roty.value = "0"
				rotz.value = "0"
			end
			if frame.shiftX then
				shfx.value = tostring(frame.shiftX)
				shfy.value = tostring(frame.shiftY)
				shfz.value = tostring(frame.shiftZ)
			else
				shfx.value = "0"
				shfy.value = "0"
				shfz.value = "0"
			end
		end
	end
	gauge:valuechanged_cb()
	local dlg = iup.dialog{
		iup.vbox{gauge, iup.hbox{iup.label{title = "Frame"}, count; gap = 10, alignment = "ACENTER"},
				iup.gridbox{
					iup.label{title = "Rotate X"}, rotx,
					iup.label{title = "Rotate Y"}, roty,
					iup.label{title = "Rotate Z"}, rotz,
					iup.label{title = "Shift X"}, shfx,
					iup.label{title = "Shift Y"}, shfy,
					iup.label{title = "Shift Z"}, shfz,
					numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
					gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2
				};
			alignment = "ACENTER", ngap = 10, nmargin = "10x10"},
		title = "Anim Data", nmargin = "10x10", size = "200x150"}
	dlg:show()
end

local button = iup.button{title = "Browse Frame Data", margin = "10x0", action = Click}

return CreateDisplay(iup.vbox{box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
