
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x13 (Animation Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	param = iup.text{readonly = "YES", visiblecolumns = 16},
	ref = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Param"}, field.param,
	iup.label{title = "Refers to"}, field.ref;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 3
}

local hex = hex
local ref

local function Update(f)
	field.flag.value = hex(f.flag)
	field.param.value = hex(f.param)
	ref = f.ref + 1
	field.ref.value = main_list[ref].name
end

local function Click()
	list.value = ref
	list:action(nil, ref, 1)
end

local button = iup.button{title = "Go To Reference", margin = "10x0", action = Click}

return CreateDisplay(iup.vbox{box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
