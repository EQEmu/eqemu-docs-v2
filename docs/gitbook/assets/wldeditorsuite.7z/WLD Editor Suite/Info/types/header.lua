
local field = {
	version = iup.text{readonly = "YES", visiblecolumns = 16},
	num_frags = iup.text{readonly = "YES", visiblecolumns = 16},
	names_len = iup.text{readonly = "YES", visiblecolumns = 16},
	unknown_a = iup.text{readonly = "YES", visiblecolumns = 16},
	unknown_b = iup.text{readonly = "YES", visiblecolumns = 16},
	unknown_c = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Version"}, field.version,
	iup.label{title = "Frag Count"}, field.num_frags,
	iup.label{title = "Names Length"}, field.names_len,
	iup.label{title = "UnknownA"}, field.unknown_a,
	iup.label{title = "UnknownB"}, field.unknown_b,
	iup.label{title = "UnknownC"}, field.unknown_c;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2, nmargin = "10x10"
}

local hex = hex
local tostring = tostring

local function Update(h)
	field.version.value = hex(h.version)
	field.num_frags.value = tostring(h.num_frags)
	field.names_len.value = tostring(h.names_len)
	field.unknown_a.value = hex(h.unknown_a)
	field.unknown_b.value = hex(h.unknown_b)
	field.unknown_c.value = hex(h.unknown_c)
end

return CreateDisplay(box, Update)
