
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x10 (Skeleton Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	num = iup.text{readonly = "YES", visiblecolumns = 16},
	ref = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Contained Bones"}, field.num,
	iup.label{title = "Refers to"}, field.ref;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2, nmargin = "10x10"
}

local hex = hex
local tostring = tostring

local list = iup.list{visiblelines = 5, expand = "VERTICAL", visiblecolumns = 18}

local function Update(f)
	field.flag.value = hex(f.flag)
	field.num.value = tostring(f.num)
	local ref = f.ref1 + 1
	if ref == 1 then
		field.ref.value = "<<none>>"
	else
		local m = main_list[ref]
		field.ref.value = m and m.name or "<<out of range>>"
	end
	if f.ref_list then
		list[#f.ref_list + 1] = nil
		for pos, ref in ipairs(f.ref_list) do
			ref = ref + 1
			local m = main_list[ref]
			list[pos] = m and m.name or "<<out of range>>"
		end
	else
		list[1] = nil
	end
end

return CreateDisplay(iup.vbox{box, list; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
