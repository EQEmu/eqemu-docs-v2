

local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x30 (Texture Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	visibility = iup.text{readonly = "YES", visiblecolumns = 16},
	other = iup.text{readonly = "YES", visiblecolumns = 16},
	float1 = iup.text{readonly = "YES", visiblecolumns = 16},
	float2 = iup.text{readonly = "YES", visiblecolumns = 16},
	pair_int = iup.text{readonly = "YES", visiblecolumns = 16},
	pair_float = iup.text{readonly = "YES", visiblecolumns = 16},
	ref = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Visibility Flag"}, field.visibility,
	iup.label{title = "Unknown Flag"}, field.other,
	iup.label{title = "Float1"}, field.float1,
	iup.label{title = "Float2"}, field.float2,
	iup.label{title = "Pair Int"}, field.pair_int,
	iup.label{title = "Pair Float"}, field.pair_float,
	iup.label{title = "Refers to"}, field.ref;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 3
}

local hex = hex
local tostring = tostring
local ref

local function Update(f)
	field.flag.value = hex(f.flag)
	field.visibility.value = hex(f.visibility)
	field.other.value = hex(f.other)
	field.float1.value = tostring(f.float1)
	field.float2.value = tostring(f.float2)
	field.pair_int.value = hex(f.pair_int)
	field.pair_float.value = tostring(f.pair_float)
	ref = f.ref + 1
	field.ref.value = main_list[ref].name
end

local function Click()
	list.value = ref
	list:action(nil, ref, 1)
end

local button = iup.button{title = "Go To Reference", margin = "10x0", action = Click}

return CreateDisplay(iup.vbox{box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
