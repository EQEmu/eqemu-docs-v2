
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x03 (Texture Data)"},
	num = iup.text{readonly = "YES", visiblecolumns = 16},
	len = iup.text{readonly = "YES", visiblecolumns = 16},
	texture_name = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Contained Names"}, field.num,
	iup.label{title = "Name Length"}, field.len,
	iup.label{title = "Texture Name"}, field.texture_name;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 1, nmargin = "10x10"
}

local tostring = tostring

local function Update(f)
	field.num.value = tostring(f.num)
	field.len.value = tostring(f.len)
	field.texture_name.value = f.texture_name
end

return CreateDisplay(box, Update)
