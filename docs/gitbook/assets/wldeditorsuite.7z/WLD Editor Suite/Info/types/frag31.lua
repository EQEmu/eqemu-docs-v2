
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x31 (Texture Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	num = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Num Texture Refs"}, field.num;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2
}

local hex = hex
local tostring = tostring

local list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 18}

local function Update(f)
	field.flag.value = hex(f.flag)
	field.num.value = tostring(f.num)
	list[#f.ref_list + 1] = nil
	for pos, ref in ipairs(f.ref_list) do
		ref = ref + 1
		local m = main_list[ref]
		list[pos] = m and m.name or "<<out of range>>"
	end
end

return CreateDisplay(iup.vbox{box, list; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
