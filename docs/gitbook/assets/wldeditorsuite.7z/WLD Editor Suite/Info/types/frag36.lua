
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x36 (Mesh Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	ref_list = {
		iup.text{readonly = "YES", visiblecolumns = 16},
		iup.text{readonly = "YES", visiblecolumns = 16},
		iup.text{readonly = "YES", visiblecolumns = 16},
		iup.text{readonly = "YES", visiblecolumns = 16},
	},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Ref1"}, field.ref_list[1],
	iup.label{title = "Ref2"}, field.ref_list[2],
	iup.label{title = "Ref3"}, field.ref_list[3],
	iup.label{title = "Ref4"}, field.ref_list[4],
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 0, nmargin = "10x10"
}

local hex = hex

local function Update(f)
	field.flag.value = hex(f.flag)
	for i = 1, 4 do
		local ref = f.ref_list[i] + 1
		if ref == 1 then
			field.ref_list[i].value = "<<none>>"
		else
			local m = main_list[ref]
			field.ref_list[i].value = m and m.name or "<<out of range>>"
		end
	end
end

return CreateDisplay(box, Update)
