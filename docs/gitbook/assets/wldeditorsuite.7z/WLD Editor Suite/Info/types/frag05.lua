
local field = {
	type = iup.text{readonly = "YES", visiblecolumns = 16, value = "0x05 (Texture Data)"},
	flag = iup.text{readonly = "YES", visiblecolumns = 16},
	ref = iup.text{readonly = "YES", visiblecolumns = 16},
}

local box = iup.gridbox{
	iup.label{title = "Type"}, field.type,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Refers to"}, field.ref;
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2
}

local hex = hex
local ref

local function Update(f)
	field.flag.value = hex(f.flag)
	ref = f.ref + 1
	local m = main_list[ref]
	field.ref.value = m and m.name or "<<out of range>>"
end

local function Click()
	list.value = ref
	list:action(nil, ref, 1)
end

local button = iup.button{title = "Go To Reference", margin = "10x0", action = Click}

return CreateDisplay(iup.vbox{box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
