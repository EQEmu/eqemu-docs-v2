
local field
local tonumber = tonumber

local button

local function Click()
	local frag = selection
	for fname, val in pairs(field) do
		if fname ~= "name" then
			frag[fname] = tonumber(val.value)
		end
	end
	if Commit(frag) then
		button.active = "NO"
	end
end

button = iup.button{title = "Commit Edit", action = Click, active = "NO", padding = "10x0"}

local function Edited()
	button.active = "YES"
	selection.edited = true
end

field = {
	name = iup.text{readonly = "YES", visiblecolumns = 16},
	flag1 = iup.text{visiblecolumns = 16, action = Edited},
	flag2 = iup.text{visiblecolumns = 16, action = Edited},
	flag3 = iup.text{visiblecolumns = 16, action = Edited},
	field4 = iup.text{visiblecolumns = 16, action = Edited},
	field5 = iup.text{visiblecolumns = 16, action = Edited},
	field6 = iup.text{visiblecolumns = 16, action = Edited},
	field7 = iup.text{visiblecolumns = 16, action = Edited},
	field8 = iup.text{visiblecolumns = 16, action = Edited},
	field9 = iup.text{visiblecolumns = 16, action = Edited},
	field10 = iup.text{visiblecolumns = 16, action = Edited},
	float1 = iup.text{visiblecolumns = 16, action = Edited},
	float2 = iup.text{visiblecolumns = 16, action = Edited},
	field13 = iup.text{visiblecolumns = 16, action = Edited},
	float3 = iup.text{visiblecolumns = 16, action = Edited},
	field15 = iup.text{visiblecolumns = 16, action = Edited},
	float4 = iup.text{visiblecolumns = 16, action = Edited},
	field17 = iup.text{visiblecolumns = 16, action = Edited},
	field18 = iup.text{visiblecolumns = 16, action = Edited},
	float5 = iup.text{visiblecolumns = 16, action = Edited},
	float6 = iup.text{visiblecolumns = 16, action = Edited},
}

local box = iup.gridbox{
	iup.label{title = "Name"}, field.name,
	iup.label{title = "Flag1"}, field.flag1,
	iup.label{title = "Flag2"}, field.flag2,
	iup.label{title = "Flag3"}, field.flag3,
	iup.label{title = "Flag4"}, field.field4,
	iup.label{title = "Max Simult"}, field.field5,
	iup.label{title = "Field6"}, field.field6,
	iup.label{title = "Field7"}, field.field7,
	iup.label{title = "Field8"}, field.field8,
	iup.label{title = "Field9"}, field.field9,
	iup.label{title = "Field10"}, field.field10,
	iup.label{title = "Float1"}, field.float1,
	iup.label{title = "Float2"}, field.float2,
	iup.label{title = "Lifetime"}, field.field13,
	iup.label{title = "Float3"}, field.float3,
	iup.label{title = "Field15"}, field.field15,
	iup.label{title = "Float4"}, field.float4,
	iup.label{title = "Field17"}, field.field17,
	iup.label{title = "Delay"}, field.field18,
	iup.label{title = "Flag5?"}, field.float5,
	iup.label{title = "Color Mask"}, field.float6,
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 5
}

local hex = hex
local tostring = tostring
local tonumber = tonumber
local floor = math.floor

local flag_button = iup.button{title = "Edit Main Flag", padding = "10x0"}

function flag_button:action()
	local ticks = {}
	local grid = iup.gridbox{
		numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
		gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 7
	}
	for i = 1, 32 do
		local t = iup.toggle{title = "Unknown ".. i, value = "OFF"}
		ticks[i] = t
		iup.Append(grid, t)
	end
	ticks[16].title = "Fixed to Source?"
	local flag = tonumber(field.field4.value)
	for i = 1, 32 do
		if flag%2 == 1 then
			ticks[i].value = "ON"
		end
		flag = floor(flag / 2)
	end
	local dlg
	local but = iup.button{title = "OK", padding = "10x0", action = function() dlg:hide() end}
	local box = iup.vbox{grid, but, gap = 20, alignment = "ACENTER", nmargin = "10x10"}
	dlg = iup.dialog{box; title = "Edit Main Flag", size = "185x260"}
	iup.Popup(dlg)
	local outflag = 0
	for i = 32, 1, -1 do
		outflag = outflag * 2
		if ticks[i].value == "ON" then
			outflag = outflag + 1
		end
	end
	local prev = field.field4.value
	local new = hex(outflag)
	if prev ~= new then
		field.field4.value = new
		button.active = "YES"
		selection.edited = true
	end
end

local function Update(f)
	field.name.value = f.name
	field.flag1.value = hex(f.flag1)
	field.flag2.value = hex(f.flag2)
	field.flag3.value = hex(f.flag3)
	field.field4.value = hex(f.field4)
	field.field5.value = tostring(f.field5)
	field.field6.value = tostring(f.field6)
	field.field7.value = tostring(f.field7)
	field.field8.value = tostring(f.field8)
	field.field9.value = tostring(f.field9)
	field.field10.value = tostring(f.field10)
	field.float1.value = tostring(f.float1)
	field.float2.value = tostring(f.float2)
	field.field13.value = tostring(f.field13)
	field.float3.value = tostring(f.float3)
	field.field15.value = tostring(f.field15)
	field.float4.value = tostring(f.float4)
	field.field17.value = tostring(f.field17)
	field.field18.value = tostring(f.field18)
	field.float5.value = hex(f.float5)
	field.float6.value = hex(f.float6)
	button.active = "NO"
	f.edited = false
end

return CreateDisplay(iup.vbox{flag_button, box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
