
local eqg = require "luaeqg"

function CreateDisplay(box, func)
	local d = {display = box, Update = func}
	return d
end

local format = string.format
function hex(int)
	return format("0x%0.8X", int)
end

local display = {
	frag26 = require("frag26"),
	frag34 = require("frag34"),
}

local type_to_display = {
	[true] = display.frag34,
	[false] = display.frag26,
}

local none = CreateDisplay(iup.hbox{}, function() end)

type_to_display.__index = function() return none end
setmetatable(type_to_display, type_to_display)

local zbox = iup.zbox{
	none.display,
	value = none.display
}

for _, d in pairs(display) do
	iup.Append(zbox, d.display)
end

function UpdateDisplay(frag, is_34)
	local d = type_to_display[is_34 and true or false]
	d.Update(frag)
	zbox.value = d.display
	selection = frag
end

function Commit(frag)
	if frag.edited then
		print(open_wld, open_wld.name)
		local s, err = pcall(CommitEdit, open_wld, frag.is_34 and 1 or 0, frag)
		if s then
			s, err = pcall(eqg.WriteDirectory, open_path, open_dir)
			if s then
				frag.edited = false
				return true
			end
		end
		error_popup(err)
	end
end

function ClearDisplay()
	zbox.value = none.display
end

return zbox
