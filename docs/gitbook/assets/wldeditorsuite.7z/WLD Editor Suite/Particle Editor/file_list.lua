
local eqg = require "luaeqg"

local list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 16}

local ipairs = ipairs
local pcall = pcall
local open_prt
local LoadParticleInfo = LoadParticleInfo

function UpdateFileList(path, name)
	eqg.CloseDirectory(open_dir)
	open_path = path
	local s, dir = pcall(eqg.LoadDirectory, path)
	if not s then
		error_popup(dir)
		return
	end
	open_dir = dir
	name = name:sub(1, -5) .. ".wld"
	list[1] = nil
	list.autoredraw = "NO"
	for i, ent in ipairs(dir) do
		if ent.name == name then
			open_wld = ent
			local s, err = pcall(eqg.OpenEntry, ent)
			if s then
				s, err = pcall(LoadParticleInfo, ent)
				if s then
					open_prt = err
					for j, frag in ipairs(err) do
						list[j] = frag.name
					end
					break
				end
			end
			error_popup(err)
			break
		end
	end
	list.autoredraw = "YES"
end

function list:action(str, pos, state)
	if state == 1 then
		local frag = open_prt[pos]
		if frag then
			UpdateDisplay(frag, frag.is_34)
		end
	end
end

return list
