
local field
local tonumber = tonumber

local button

local function Click()
	local frag = selection
	frag.flag = tonumber(field.flag.value)
	frag.vis_flag = tonumber(field.vis_flag.value)
	if Commit(frag) then
		button.active = "NO"
	end
end

button = iup.button{title = "Commit Edit", action = Click, active = "NO", padding = "10x0"}

local function Edited()
	button.active = "YES"
	selection.edited = true
end

field = {
	name = iup.text{readonly = "YES", visiblecolumns = 16},
	flag = iup.text{visiblecolumns = 16, action = Edited},
	vis_flag = iup.text{visiblecolumns = 16, action = Edited},
}

local box = iup.gridbox{
	iup.label{title = "Name"}, field.name,
	iup.label{title = "Flag"}, field.flag,
	iup.label{title = "Visibility Flag"}, field.vis_flag,
	numdiv = 2, orientation = "HORIZONTAL", homogeneouslin = "YES",
	gapcol = 10, gaplin = 8, alignmentlin = "ACENTER", sizelin = 2
}

local hex = hex
local tostring = tostring

local function Update(f)
	field.name.value = f.name
	field.flag.value = hex(f.flag)
	field.vis_flag.value = hex(f.vis_flag)
	button.active = "NO"
	f.edited = false
end

return CreateDisplay(iup.vbox{box, button; nmargin = "10x10", gap = 20, alignment = "ACENTER"}, Update)
