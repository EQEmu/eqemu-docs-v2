
local lfs = require "lfs"

local list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 14, sort = "YES"}

function UpdateDirList(path)
	list[1] = nil
	list.autoredraw = "NO"
	local i = 1
	for str in lfs.dir(path) do
		if str:match("%.s3d", -4) then
			list[i] = str
			i = i + 1
		end
	end
	list.autoredraw = "YES"
end

function list:action(str, pos, state)
	if state == 1 then
		ClearDisplay()
		local path = search_path .."\\".. str
		UpdateFileList(path, str)
	end
end

return list
