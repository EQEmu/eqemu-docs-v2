
local list = iup.list{visiblelines = 10, expand = "VERTICAL", visiblecolumns = 5, sort = "YES"}

local ipairs = ipairs
local format = string.format
local tonumber = tonumber

function UpdateList(tbl)
	list[1] = nil
	for pos, name in ipairs(tbl) do
		list[pos] = name
	end
end

local function Click()
	local s, err = pcall(CopyTextureSet, wld_path, selection, high_ids)
	if s then
		local s, ids, tbl = pcall(GetTextureSets, wld_path)
		if s then
			high_ids = ids
			UpdateList(tbl)
		else
			error_popup(ids)
		end
	else
		error_popup(err)
	end
end

local button = iup.button{title = "Add Texture Set", action = Click, active = "NO"}

function list:action(str, pos, state)
	if state == 1 then
		selection = str
		button.active = "YES"
	end
end

return iup.hbox{list, button; gap = 10}
