
function assert(result, msg)
	if result then return result end
	local err = iup.messagedlg{buttons = "OK", dialogtype = "ERROR", title = "Error", value = msg}
	iup.Popup(err)
	iup.Close()
end

function error_popup(msg)
	local err = iup.messagedlg{buttons = "OK", dialogtype = "ERROR", title = "Error", value = msg}
	iup.Popup(err)
end

local list = require "list"

local pcall = pcall
local LoadWLD = LoadWLD
local UpdateList = UpdateList

local function HandleLoad()
	local dlg = iup.filedlg{title = "Select WLD", extfilter = "*.wld (WLD Files)|*.wld|"}
	iup.Popup(dlg)
	if dlg.status == "0" then
		local path = dlg.value
		if path then
			local s, ids, tbl = pcall(GetTextureSets, path)
			if s then
				wld_path = path
				high_ids = ids
				UpdateList(tbl)
			else
				error_popup(ids)
			end
		end
	end
end

local function About()
	iup.Message("About", "Created by Zaela\nConsultant\nShards of Dalaya server\nwww.shardsofdalaya.com")
end

local menu = iup.menu{
	iup.submenu{
		title = "&File";
		iup.menu{
			iup.item{title = "Load WLD", action = HandleLoad},
			iup.item{title = "About", action = About},
		},
	},
}

local window = assert(iup.dialog{iup.hbox{list; nmargin = "10x10"};
	title = "WLD Texture Adder", menu = menu, size = "200x200"})

function window:k_any(key)
	if key == iup.K_ESC then
		iup.Close()
	end
end

window:show()
iup.MainLoop()
